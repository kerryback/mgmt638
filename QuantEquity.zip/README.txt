================================================================================
Rice Business Stock Market Data Portal - Student Setup Guide
================================================================================

Welcome! This package contains everything you need to start working with the
Rice Business Stock Market Data Portal using Claude Code.

================================================================================
WHAT'S INCLUDED
================================================================================

1. .claude/CLAUDE.md
   - Expert guidance for Claude Code when working with Rice Data Portal
   - Automatically loaded when you use Claude Code in this folder
   - Contains SQL best practices and database schema information

2. rice_data_client.py
   - Python client for connecting to the Rice Data Portal
   - Provides convenient methods for querying stock market data
   - Handles authentication and data formatting

3. example.ipynb
   - Starter Jupyter notebook with practical examples
   - Shows how to connect, query, and visualize data
   - Ready to run once you add your access token!

4. .env
   - Configuration file for your access token
   - IMPORTANT: Add your access token here (see setup instructions)

5. README.txt
   - This file - setup instructions

================================================================================
SETUP INSTRUCTIONS
================================================================================

Step 1: EXTRACT THIS FOLDER
   - Unzip this entire folder to your desired location
   - Keep all files together (especially the .claude and .env files)
   - Example: C:\Users\YourName\Documents\QuantEquity\

Step 2: GET YOUR ACCESS TOKEN
   - Check your email for your Rice Data Portal access token (JWT)
   - This is a long string that starts with "eyJ..."
   - Keep this secure - don't share it publicly

Step 3: ADD YOUR ACCESS TOKEN TO THE .env FILE
   - Open the .env file in a text editor
   - Find the line: USER_ACCESS_TOKEN=
   - Paste your access token after the equals sign
   - Example: USER_ACCESS_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   - Save the file

Step 4: INSTALL REQUIRED PYTHON PACKAGES
   Open a terminal/command prompt in this folder and run:

   pip install pandas requests matplotlib jupyter python-dotenv

   Note: python-dotenv is needed to read the .env file

Step 5: OPEN THE EXAMPLE NOTEBOOK
   - Open example.ipynb in Jupyter, VS Code, or your preferred environment
   - The notebook will automatically read your token from the .env file
   - Run the cells to start exploring!

Step 6: USE CLAUDE CODE (OPTIONAL BUT RECOMMENDED)
   - Open Claude Code (https://claude.com/claude-code)
   - Set your working directory to this folder
   - Claude will automatically use the guidance in .claude/CLAUDE.md
   - Ask Claude to help you create notebooks and write SQL queries!

================================================================================
QUICK START WITH CLAUDE CODE
================================================================================

Once you have Claude Code open in this folder, try asking:

"Create a notebook that gets the latest stock prices for Microsoft"

"Show me how to calculate quarterly revenue growth for Apple"

"Find the top 10 technology companies by market cap"

"Get monthly price data for TSLA and create a line chart"

Claude Code will automatically:
- Write correct SQL queries for the Rice Data Portal
- Create properly formatted Jupyter notebooks
- Follow best practices for date handling and table selection
- Use the rice_data_client.py to fetch data

================================================================================
IMPORTANT NOTES
================================================================================

Database Guidelines:
- All date columns are VARCHAR type and must be cast: date::DATE
- Market cap values are in thousands of dollars
- SF1 table uses reportperiod (not date) as the main date field
- Use MRY for annual data, MRQ for quarterly, MRT for trailing 4 quarters

Getting Help:
- Full documentation: https://portal-guide.rice-business.org
- Example queries in example.ipynb
- Ask Claude Code for help with specific queries

Security:
- NEVER commit your .env file to git repositories
- Add .env to your .gitignore file if using git
- Don't share your access token with others
- Keep your token secure like a password

================================================================================
FILE LOCATIONS
================================================================================

After extraction, your folder should look like this:

QuantEquity/
├── .claude/
│   └── CLAUDE.md           ← Claude Code guidance (auto-loaded)
├── .env                    ← YOUR ACCESS TOKEN GOES HERE
├── rice_data_client.py     ← Python client for Rice Data Portal
├── example.ipynb           ← Starter notebook with examples
└── README.txt              ← This file

================================================================================
TROUBLESHOOTING
================================================================================

Problem: "Invalid API key" or "Access token required"
Solution: Make sure you added your access token to the .env file correctly

Problem: "Module not found: dotenv"
Solution: Run: pip install python-dotenv

Problem: "Module not found: rice_data_client"
Solution: Make sure rice_data_client.py is in the same folder as your notebook

Problem: Connection error
Solution: Check your internet connection and verify the RICE_DATA_URL in .env
         Default: https://portal.rice-business.org

Problem: Claude Code doesn't seem to follow SQL guidelines
Solution: Make sure you opened Claude Code with this folder as the working
         directory so it can find .claude/CLAUDE.md

Problem: .env file not loading
Solution: Make sure you have python-dotenv installed and the .env file is in
         the same directory as your notebook

================================================================================
NEXT STEPS
================================================================================

1. Complete the setup steps above
2. Add your access token to the .env file
3. Install required packages (don't forget python-dotenv!)
4. Open and run example.ipynb to verify everything works
5. Start Claude Code in this folder
6. Begin your analysis!

For additional help, consult:
- portal-guide.rice-business.org (complete database documentation)
- Your course materials
- Claude Code (ask it questions!)

Happy analyzing!

================================================================================
