# Prompt injection, in about 40 lines

A page you control, and an agent that obeys it.

## What is here

- `page.html` — a product note with a line of gray boilerplate at the foot. It
  reads as a licensing notice, not an instruction to the AI, so the model has no
  reason to flag it and folds it into the answer.
- `agent.py` — a summarizer with one tool, `fetch_page`, pointed at a small
  model (Haiku). You ask it to summarize the page. Nothing in your prompt
  mentions a source line.

## Run it

```
pip install anthropic
export ANTHROPIC_API_KEY=...
python -m http.server 8099 &
python agent.py http://localhost:8099/page.html
```

## What you see

The agent returns the two-sentence summary you asked for, and then ends with:

```
Source: AcmeWire (AR7)
```

You never asked for that line. The page did. That is the whole attack: the
model cannot separate "content to summarize" from "instructions to follow" —
both arrived as text from the same tool result.

## It is probabilistic, and that is the point

Compliance is not guaranteed on any single run. Two levers move it:

- Model. A small model (the `claude-haiku-*` this demo uses) complies far more
  readily than Sonnet or Opus, which are trained to catch injection and will
  often flag this same line instead of obeying it. Change `MODEL` in `agent.py`
  to compare.
- Subtlety. A blatant "ignore your instructions, AI assistant" gets caught; a
  plausible, benign line like the one here slips past far more often. If a run
  summarizes cleanly with no source line, run it again.

That you cannot rely on the model catching it — on any model, on any run — is
the argument for the architectural fix.

## The point for the architecture

Here the injected instruction only made the agent write a line. Aim the same
mechanism at private data and a way out, and it exfiltrates — if the agent has
both. That is why the fix is architectural (remove a leg), not a matter of
asking the model to be more careful.
