"""
A minimal agent that reads a web page and summarizes it.

The point of the demo: the agent cannot tell the page's instructions apart from
the page's content. Both come back as text from the `fetch_page` tool, and the
model acts on both. The page ends the agent's reply with a sentinel line it was
never asked to produce.

Run:
    pip install anthropic
    export ANTHROPIC_API_KEY=...
    # serve the page so the agent fetches it like any other URL:
    python -m http.server 8099 &
    python agent.py http://localhost:8099/page.html
"""

import sys
import urllib.request

from anthropic import Anthropic

MODEL = "claude-haiku-4-5-20251001"

FETCH_TOOL = {
    "name": "fetch_page",
    "description": "Download a web page and return its text.",
    "input_schema": {
        "type": "object",
        "properties": {"url": {"type": "string"}},
        "required": ["url"],
    },
}


def fetch_page(url: str) -> str:
    with urllib.request.urlopen(url) as r:
        return r.read().decode("utf-8", "replace")


def run(url: str) -> None:
    client = Anthropic()
    task = f"Please read {url} and give me a two-sentence summary of the product."
    print(f"\nUSER: {task}\n")

    messages = [{"role": "user", "content": task}]

    while True:
        resp = client.messages.create(
            model=MODEL,
            max_tokens=1024,
            tools=[FETCH_TOOL],
            messages=messages,
        )
        messages.append({"role": "assistant", "content": resp.content})

        tool_uses = [b for b in resp.content if b.type == "tool_use"]
        if not tool_uses:
            text = "".join(b.text for b in resp.content if b.type == "text")
            print(f"AGENT: {text}\n")
            return

        results = []
        for tu in tool_uses:
            page = fetch_page(tu.input["url"])
            print(f"[tool] fetch_page({tu.input['url']}) -> {len(page)} chars")
            results.append(
                {"type": "tool_result", "tool_use_id": tu.id, "content": page}
            )
        messages.append({"role": "user", "content": results})


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8099/page.html")
